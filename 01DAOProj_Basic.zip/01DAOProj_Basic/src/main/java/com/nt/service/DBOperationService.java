package com.nt.service;

import java.util.List;
import java.util.Map;

public interface DBOperationService {
public String register(int no,String name,String job,double sal);
public int fetchSalary(int no);
public String updateSalary(int no,int per);
public String deleteEmp(int no);
public Map<String ,Object> fetchEmpDetails(int no) throws Exception;
public List<Map<String,Object>> fetchAllEmpDetails()throws Exception;
}
