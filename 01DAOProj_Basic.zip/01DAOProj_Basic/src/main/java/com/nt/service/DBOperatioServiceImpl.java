package com.nt.service;

import java.util.List;
import java.util.Map;

import com.nt.dao.DBOperations;

public class DBOperatioServiceImpl implements DBOperationService {

    DBOperations dao=null;
    
	public void setDao(DBOperations dao) {
		this.dao = dao;
	}

	@Override
	public String register(int no, String name, String job, double sal) {

	     int result=0;
	     String msg=null;
	     //use dao
	     result=dao.insert(no, name, job, sal);
	     if(result==0){
	    	 return no+" Registration is not successfull";
	     }
	     else
	    	 return no+"  Registration is sucessfully";
	     }

	@Override
	public int fetchSalary(int no) {	
		return dao.getSalary(no);
	}

	@Override
	public String updateSalary(int no, int per) {
		int res=0;
		double salary=dao.getSalary(no);
		System.out.println("Old Salary::"+salary);
		salary=salary+(salary*per/100);
		res=dao.upadate(no, salary);
		if(res==0){
			return no+"  employee salary not hiked";
		}
		else
			return no+" employeesalary is hiked new salary is:::"+salary;
	}
	@Override
	    public String deleteEmp(int no) {
		  int count=0;
	   count= 	dao.delete(no);
	   if(count==0){
		   return no+" record not found";
	   }
	   else
	    	return no+"   record deleted sucessfully";
	    }     
	     @Override
	    public Map<String, Object> fetchEmpDetails(int no) throws Exception {
	    	Map<String ,Object> map1=dao.empDetaile(no);
	    	if(map1!=null)
	    	return map1;
	    	else
	    		throw new Exception(no+ "employee not found");
	    }

		@Override
		public List<Map<String, Object>> fetchAllEmpDetails() throws Exception {
			List<Map<String,Object>> list=dao.listAllEmpDetails();
			if((list!=null))
			return list;
			else
				throw new Exception( "No Record not found");
		}
	}
