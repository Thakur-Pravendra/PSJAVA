package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.nt.service.DBOperatioServiceImpl;

public class DBTest {

	public static void main(String[] args) throws Exception {	
		ApplicationContext ctx=null;
		DBOperatioServiceImpl service=null;
         //create IOC contaier
		ctx=new FileSystemXmlApplicationContext("src/main/java/com/nt/cfgs/applicationContext.xml");
		//use service
		service=ctx.getBean("service",DBOperatioServiceImpl.class);
	//	System.out.println(service.register(102, "Rani", "Clerk", 5000.00));
	//	System.out.println("Salary ::"+service.fetchSalary(101));
		//System.out.println(service.updateSalary(101, 10));
//	System.out.println(service.deleteEmp(102));
	System.out.println(service.fetchEmpDetails(101));
		//System.out.println(service.fetchAllEmpDetails());
		((AbstractApplicationContext) ctx).close();
	}

}
