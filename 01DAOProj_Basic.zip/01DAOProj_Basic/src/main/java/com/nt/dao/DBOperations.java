package com.nt.dao;


import java.util.List;
import java.util.Map;

public interface DBOperations {
	public int insert(int no,String name,String job ,double sal);
	public int getSalary(int no);
    public int upadate(int no,double newSal);
    public int delete(int no);
    public Map<String,Object> empDetaile(int no);
    public List<Map<String,Object>> listAllEmpDetails();
}
