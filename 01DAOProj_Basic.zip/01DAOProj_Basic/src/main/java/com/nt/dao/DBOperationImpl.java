package com.nt.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

public class DBOperationImpl implements DBOperations {	
	private static final String INSERT_QUERY="INSERT INTO EMPLOYEE VALUES(?,?,?,?)";
	private static final String GET_SALATY="SELECT SAL FROM EMPLOYEE WHERE NO=?";
	private static final String UPDATE_SALARY="UPDATE EMPLOYEE SET SAL=? WHERE NO=?";
	private static final String DELETE_QUERY="DELETE FROM EMPLOYEE WHERE NO=?";
	private static final String EMP_DETAILS="SELECT 	NO,NAME,JOB,SAL FROM EMPLOYEE WHERE NO=?";
	private static final String ALL_EMP_DETAILS="SELECT * FROM EMPLOYEE";
	private JdbcTemplate jt;
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	@Override
	public int insert(int no, String name, String job, double sal) {
	    int result =0;
	    result=jt.update(INSERT_QUERY,no,name,job,sal);
		return result;
	}
	@Override
	public int getSalary(int no) {
		int sal=0;
		sal=jt.queryForObject(GET_SALATY, Integer.class,no);
		return sal;
	}
	@Override
	public int upadate(int no, double newSal) {
		int count=0;
		 count=jt.update(UPDATE_SALARY,newSal,no);
		return count;
	}
	@Override
	public int delete(int no) {
		int count=jt.update(DELETE_QUERY,no);
		return count;
	}
	@Override
	public Map<String, Object> empDetaile(int no) {
		Map<String ,Object> map=jt.queryForMap(EMP_DETAILS,no);
		return map;
	}
	@Override
	public List<Map<String, Object>> listAllEmpDetails() {
		List<Map<String ,Object>> list=jt.queryForList(ALL_EMP_DETAILS);
		return list;
	}
	

}
